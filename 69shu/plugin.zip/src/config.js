    var host = 'https://www.69shuba.com';
