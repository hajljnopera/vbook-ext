load('libs.js');

function execute(url) {

    // Bypass cloudflare
    var browser = Engine.newBrowser();
    browser.launch(url, 10 * 1000);
    var doc = browser.html();

    var host = 'https://skymanga.co';
    var elems = $.QA(doc, 'li.wp-manga-chapter > a', {reverse: true});

    var data = [];
    elems.forEach(function(e) {
        data.push({
            name: e.text(),
            url: e.attr('href'),
            host: host
        })
    });

    browser.close();
    
    if (data.length) return Response.success(data);

    return Response.error(url);
}