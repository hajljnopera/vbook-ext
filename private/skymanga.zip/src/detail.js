load('libs.js');

function execute(url) {

    // Bypass cloudflare
    var browser = Engine.newBrowser();
    browser.launch(url, 10 * 1000);
    var doc = browser.html();

    browser.close();

    return Response.success({
        name: $.Q(doc, 'div.post-title > h1', {remove: 'span'}).text().trim(),
        cover: imgproxify($.Q(doc, 'div.summary_image img').attr('data-src')) || '',
        author: $.Q(doc, 'div.author-content').text(),
        description: $.Q(doc, 'div.description-summary').text().replace('Show more').trim() || 'updating',
        detail: '',
        host: 'https://skymanga.co',
    });
}

function imgproxify(url) {
    return 'https://cdn.imgproxify.com/image?url=' + url;
}