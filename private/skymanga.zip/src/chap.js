load('libs.js');

function execute(url) {

	// Bypass cloudflare
    var browser = Engine.newBrowser();
    browser.launch(url, 10 * 1000);

    var queryImages = 'div.reading-content img[data-src]';
    var doc = browser.html();
    var elems = $.QA(doc, queryImages);

    var imgs = [];
    elems.forEach(function(e) {
        var img = e.attr('data-src');
        if (img) imgs.push(img.trim());
    })

    browser.close();

    if (imgs.length) return Response.success(imgs);

    return Response.error(url);
}