load('libs.js');

function execute(url, page) {
    var host = 'https://skymanga.co';
    // Bypass cloudflare
    
    page = page || '1';
    var newUrl = page == '1' ? host : String.format(host + url, page);

    var browser = Engine.newBrowser();
    browser.launch(newUrl, 15*1000);
    var doc = browser.html();
    var data = [];

    var elems = $.QA(doc, 'div.page-item-detail');

    elems.forEach(function(e) {
        data.push({
            name: $.Q(e, 'h3 a').text(),
            link: $.Q(e, 'h3 a').attr('href'),
            cover: imgproxify($.Q(e, 'div.item-thumb img').attr('data-src')),
            description: $.Q(e, 'div.chapter-item > span > a').text(),
            host: host
        })
    });

    browser.close();
    // log(data);
    
    var next = $.Q(doc, '.nav-links .nav-previous > a').attr('href');
    if (next) next = next.match(/page\/(\d+)/)[1];

    if (data.length) return Response.success(data, next);

    return Response.error(host);
}

function imgproxify(url) {
    return 'https://cdn.imgproxify.com/image?url=' + url;
}