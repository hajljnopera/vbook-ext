function execute() {
    return Response.success([
        {title: "Home", input: "/", script: "gen.js"},
    ]);
}