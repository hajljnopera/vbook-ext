function execute() {
    return Response.success([
        {
            "input": "https://manganelo.com/genre-2/{0}",
            "title": "Action",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-3/{0}",
            "title": "Adult",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-4/{0}",
            "title": "Adventure",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-6/{0}",
            "title": "Comedy",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-7/{0}",
            "title": "Cooking",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-9/{0}",
            "title": "Doujinshi",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-10/{0}",
            "title": "Drama",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-11/{0}",
            "title": "Ecchi",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-12/{0}",
            "title": "Fantasy",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-13/{0}",
            "title": "Gender bender",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-14/{0}",
            "title": "Harem",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-15/{0}",
            "title": "Historical",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-16/{0}",
            "title": "Horror",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-45/{0}",
            "title": "Isekai",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-17/{0}",
            "title": "Josei",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-44/{0}",
            "title": "Manhua",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-43/{0}",
            "title": "Manhwa",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-19/{0}",
            "title": "Martial arts",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-20/{0}",
            "title": "Mature",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-21/{0}",
            "title": "Mecha",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-22/{0}",
            "title": "Medical",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-24/{0}",
            "title": "Mystery",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-25/{0}",
            "title": "One shot",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-26/{0}",
            "title": "Psychological",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-27/{0}",
            "title": "Romance",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-28/{0}",
            "title": "School life",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-29/{0}",
            "title": "Sci fi",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-30/{0}",
            "title": "Seinen",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-31/{0}",
            "title": "Shoujo",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-32/{0}",
            "title": "Shoujo ai",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-33/{0}",
            "title": "Shounen",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-34/{0}",
            "title": "Shounen ai",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-35/{0}",
            "title": "Slice of life",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-36/{0}",
            "title": "Smut",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-37/{0}",
            "title": "Sports",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-38/{0}",
            "title": "Supernatural",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-39/{0}",
            "title": "Tragedy",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-40/{0}",
            "title": "Webtoons",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-41/{0}",
            "title": "Yaoi",
            "script": "gen.js"
        },
        {
            "input": "https://manganelo.com/genre-42/{0}",
            "title": "Yuri",
            "script": "gen.js"
        }
    ]);
}