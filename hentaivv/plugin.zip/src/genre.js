function execute() {

	// li.dropdown.open > ul > li
	return Response.success([
        {
            "input": "ahegao",
            "title": "Ahegao",
            "script": "cat.js"
        },
        {
            "input": "anal",
            "title": "Anal",
            "script": "cat.js"
        },
        {
            "input": "bdsm",
            "title": "BDSM",
            "script": "cat.js"
        },
        {
            "input": "big-ass",
            "title": "Big Ass",
            "script": "cat.js"
        },
        {
            "input": "big-boobs",
            "title": "Big Boobs",
            "script": "cat.js"
        },
        {
            "input": "big-breasts",
            "title": "Big Breasts",
            "script": "cat.js"
        },
        {
            "input": "big-penis",
            "title": "Big Penis",
            "script": "cat.js"
        },
        {
            "input": "blowjobs",
            "title": "BlowJobs",
            "script": "cat.js"
        },
        {
            "input": "cheating",
            "title": "Cheating",
            "script": "cat.js"
        },
        {
            "input": "comic",
            "title": "Comic",
            "script": "cat.js"
        },
        {
            "input": "dirty-old-man",
            "title": "Dirty Old Man",
            "script": "cat.js"
        },
        {
            "input": "doujinshi",
            "title": "Doujinshi",
            "script": "cat.js"
        },
        {
            "input": "gangbang",
            "title": "GangBang",
            "script": "cat.js"
        },
        {
            "input": "glasses",
            "title": "Glasses",
            "script": "cat.js"
        },
        {
            "input": "hairy",
            "title": "Hairy",
            "script": "cat.js"
        },
        {
            "input": "full-color",
            "title": "Hentai Màu | Truyện Tranh Sex Full Màu",
            "script": "cat.js"
        },
        {
            "input": "hiep-dam",
            "title": "Hiếp Dâm",
            "script": "cat.js"
        },
        {
            "input": "housewife",
            "title": "Housewife",
            "script": "cat.js"
        },
        {
            "input": "impregnation",
            "title": "Impregnation",
            "script": "cat.js"
        },
        {
            "input": "loli",
            "title": "Loli",
            "script": "cat.js"
        },
        {
            "input": "loan-luan",
            "title": "Loạn Luân",
            "script": "cat.js"
        },
        {
            "input": "milf",
            "title": "Milf",
            "script": "cat.js"
        },
        {
            "input": "mind-break",
            "title": "Mind Break",
            "script": "cat.js"
        },
        {
            "input": "me-con",
            "title": "Mẹ Con",
            "script": "cat.js"
        },
        {
            "input": "ntr",
            "title": "NTR",
            "script": "cat.js"
        },
        {
            "input": "nakadashi",
            "title": "Nakadashi",
            "script": "cat.js"
        },
        {
            "input": "nu-sinh",
            "title": "Nữ Sinh",
            "script": "cat.js"
        },
        {
            "input": "paizuri",
            "title": "Paizuri",
            "script": "cat.js"
        },
        {
            "input": "pregnant",
            "title": "Pregnant",
            "script": "cat.js"
        },
        {
            "input": "sex-toy",
            "title": "Sex Toy",
            "script": "cat.js"
        },
        {
            "input": "shota",
            "title": "Shota",
            "script": "cat.js"
        },
        {
            "input": "some",
            "title": "Some",
            "script": "cat.js"
        },
        {
            "input": "stockings",
            "title": "Stockings",
            "script": "cat.js"
        },
        {
            "input": "swimsuit",
            "title": "Swimsuit",
            "script": "cat.js"
        },
        {
            "input": "thu-dam",
            "title": "Thủ Dâm (Masturbation)",
            "script": "cat.js"
        },
        {
            "input": "x-ray",
            "title": "X-Ray",
            "script": "cat.js"
        }
	])
}